# FurBot
Furry Discord Bot - [Click Here to Invite](https://discordapp.com/oauth2/authorize?&client_id=174176308396425217&scope=bot&permissions=403041495)

If you found this page trying to google for the bot's commands, use `f.help` in discord.

#### Original Bot (GraveBot):
- Gravestorm  *(Maintainer)* - [@Gravestorm](https://github.com/Gravestorm)
- Dustin Blackman *(Maintainer)* - [@dustinblackman](https://github.com/dustinblackman)
